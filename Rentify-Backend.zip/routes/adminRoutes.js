const express = require('express');
const router = express.Router();
const { protect, isAdmin, isLawReviewer } = require('../middlewares/authMiddleware');
const {
  getStats,
  getUsers,
  getUserById,
  toggleUserBan,
  changeUserRole,
  getAllAgreements,
  getAuditLogs,
  getClauses,
  createClause,
  reviewClause,
  archiveClause,
  restoreClause,
  getAllProperties,
  kickTenantFromProperty,
  getAdminAnalytics,
  getBillingUsers,
  getPaymentsForApproval,
  approvePaymentForLandlord,
  getClauseVariables,
  getBrandingSettings,
  updateBrandingSettings,
} = require('../controllers/adminController');

// ─── Platform Stats ───────────────────────────────────────────────────────────
router.get('/stats', protect, isAdmin, getStats);
router.get('/analytics', protect, isAdmin, getAdminAnalytics);

// ─── User Management ──────────────────────────────────────────────────────────
router.get('/users', protect, isAdmin, getUsers);
router.get('/users/:id', protect, isAdmin, getUserById);
router.put('/users/:id/ban', protect, isAdmin, toggleUserBan);
router.put('/users/:id/role', protect, isAdmin, changeUserRole);

// ─── Agreements Monitor ───────────────────────────────────────────────────────
router.get('/agreements', protect, isAdmin, getAllAgreements);

// ─── Property Management ─────────────────────────────────────────────────────
router.get('/properties', protect, isAdmin, getAllProperties);
router.post('/properties/:id/kick-tenant', protect, isAdmin, kickTenantFromProperty);

// ─── Audit Logs ───────────────────────────────────────────────────────────────
router.get('/audit-logs', protect, isAdmin, getAuditLogs);

// ─── Clause / Template Management (Admin + Law Reviewer) ─────────────────────
// isLawReviewer allows both admin and law_reviewer roles
//
// IMPORTANT: /clauses/variables MUST be registered before /clauses/:id
// otherwise Express matches the string "variables" as an :id param value.
router.get('/clauses/variables', protect, isLawReviewer, getClauseVariables);
router.get('/clauses', protect, isLawReviewer, getClauses);
router.post('/clauses', protect, isLawReviewer, createClause);
router.put('/clauses/:id/approve', protect, isLawReviewer, reviewClause);
router.put('/clauses/:id/archive', protect, isAdmin, archiveClause);
router.put('/clauses/:id/restore', protect, isAdmin, restoreClause);

// ─── Document Verification ────────────────────────────────────────────────────
const { getPendingVerifications, getApprovedVerifications, approveVerification, rejectVerification } = require('../controllers/adminController');
router.get('/verifications/pending', protect, isAdmin, getPendingVerifications);
router.get('/verifications/approved', protect, isAdmin, getApprovedVerifications);
router.put('/verifications/:userId/approve', protect, isAdmin, approveVerification);
router.put('/verifications/:userId/reject', protect, isAdmin, rejectVerification);

// ─── Billing Overview ─────────────────────────────────────────────────────────
router.get('/billing/users', protect, isAdmin, getBillingUsers);

// ─── Payment Approval Queue ───────────────────────────────────────────────────
router.get('/payments', protect, isAdmin, getPaymentsForApproval);
router.put('/payments/:paymentId/approve', protect, isAdmin, approvePaymentForLandlord);

// ─── Admin Settings ───────────────────────────────────────────────────────────
router.get('/settings/branding', protect, isAdmin, getBrandingSettings);
router.put('/settings/branding', protect, isAdmin, updateBrandingSettings);

module.exports = router;