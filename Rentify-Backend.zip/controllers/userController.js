const User = require('../models/User');
const Agreement = require('../models/Agreement');
const Property = require('../models/Property');
const Payment = require('../models/Payment');
const MaintenanceRequest = require('../models/MaintenanceRequest');

function getStripeClient() {
  return require('stripe')(process.env.STRIPE_SECRET_KEY);
}

// @desc    Find user by email (used when landlord types tenant email to create agreement)
// @route   POST /api/users/lookup
const getUserByEmail = async (req, res) => {
  try {
    const { email } = req.body;
    const user = await User.findOne({ email }).select('name email role');
    if (!user) return res.status(404).json({ message: 'User not found' });
    res.json(user);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get own profile (full data)
// @route   GET /api/users/me
// @access  Private
const getMe = async (req, res) => {
  try {
    const user = await User.findById(req.user._id).select(
      '-password -passwordResetToken -passwordResetExpiry -emailVerificationToken -otpCode -otpExpiry -otpAttempts -fcmToken -twoFactorSecret'
    );
    if (!user) return res.status(404).json({ message: 'User not found' });
    res.json(user);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get own profile
// @route   GET /api/users/profile
// @access  Private
const getProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user._id).select(
      '-password -passwordResetToken -passwordResetExpiry -emailVerificationToken -otpCode -otpExpiry -otpAttempts -fcmToken -twoFactorSecret'
    );
    if (!user) return res.status(404).json({ message: 'User not found' });
    res.json(user);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Update own profile (name, phone, profilePhoto, smsOptIn, emailOptIn)
// @route   PUT /api/users/profile
// @access  Private
const updateProfile = async (req, res) => {
  try {
    const allowed = ['name', 'phoneNumber', 'profilePhoto', 'smsOptIn', 'emailOptIn', 'role'];
    const updates = {};
    for (const key of allowed) {
      if (req.body[key] !== undefined) {
        // Only allow role change for Google users completing profile (from tenant to another)
        if (key === 'role' && !['landlord', 'tenant', 'property_manager'].includes(req.body[key])) continue;
        updates[key] = req.body[key];
      }
    }
    // If phone changes, reset phone verification
    if (updates.phoneNumber && updates.phoneNumber !== req.user.phoneNumber) {
      updates.isPhoneVerified = false;
    }

    const user = await User.findByIdAndUpdate(
      req.user._id,
      updates,
      { returnDocument: 'after', runValidators: true }
    ).select('-password -passwordResetToken -passwordResetExpiry -emailVerificationToken -otpCode -otpExpiry -otpAttempts -fcmToken -twoFactorSecret');

    res.json(user);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Update notification preferences
// @route   PATCH /api/users/me/preferences
// @access  Private
const updatePreferences = async (req, res) => {
  try {
    const { smsOptIn, emailOptIn } = req.body;
    const updates = {};
    if (smsOptIn !== undefined) updates.smsOptIn = smsOptIn;
    if (emailOptIn !== undefined) updates.emailOptIn = emailOptIn;
    const user = await User.findByIdAndUpdate(req.user._id, updates, { returnDocument: 'after' })
      .select('smsOptIn emailOptIn');
    res.json(user);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get allowed messaging contacts based on role
// @route   GET /api/users/contacts
// @access  Private
const getContacts = async (req, res) => {
  try {
    const userId = req.user._id;
    const role = req.user.role;
    let contacts = [];

    if (role === 'landlord') {
      // Landlord sees: active tenants, payment-pending tenants (signed/sent), and their PMs
      const agreements = await Agreement.find({ landlord: userId, status: { $in: ['active', 'signed', 'sent'] } })
        .populate('tenant', 'name email role profilePhoto')
        .populate('property', 'title _id');
      const properties = await Property.find({ landlord: userId, managedBy: { $ne: null } })
        .populate('managedBy', 'name email role profilePhoto');

      const tenants = agreements.map(a => ({
        user: a.tenant,
        propertyId: a.property?._id,
        propertyTitle: a.property?.title,
        // Only fully active agreements are "Active Tenant"; signed/sent = awaiting payment
        context: a.status === 'active' ? 'Active Tenant' : 'Payment Pending',
      }));
      const managers = properties.map(p => ({
        user: p.managedBy,
        propertyId: p._id,
        propertyTitle: p.title,
        context: 'Property Manager',
      }));
      contacts = [...tenants, ...managers];

    } else if (role === 'tenant') {
      // Tenant sees: landlord + PM for active OR signed/sent leases
      // Include 'signed' so tenant can contact landlord/PM before initial payment is confirmed
      const agreements = await Agreement.find({ tenant: userId, status: { $in: ['active', 'signed', 'sent'] } })
        .populate('landlord', 'name email role profilePhoto')
        .populate('property', 'title _id');

      for (const ag of agreements) {
        contacts.push({
          user: ag.landlord,
          propertyId: ag.property?._id,
          propertyTitle: ag.property?.title,
          context: 'Landlord',
        });
        // Check if property has PM
        const prop = await Property.findById(ag.property?._id).populate('managedBy', 'name email role profilePhoto');
        if (prop?.managedBy) {
          contacts.push({
            user: prop.managedBy,
            propertyId: prop._id,
            propertyTitle: prop.title,
            context: 'Property Manager',
          });
        }
      }

    } else if (role === 'property_manager') {
      // PM sees: landlords who assigned properties + tenants of those properties
      const properties = await Property.find({ managedBy: userId })
        .populate('landlord', 'name email role profilePhoto');

      for (const prop of properties) {
        contacts.push({
          user: prop.landlord,
          propertyId: prop._id,
          propertyTitle: prop.title,
          context: 'Landlord',
        });
        // Find active tenants of this property
        const agreements = await Agreement.find({ property: prop._id, status: 'active' })
          .populate('tenant', 'name email role profilePhoto');
        for (const ag of agreements) {
          contacts.push({
            user: ag.tenant,
            propertyId: prop._id,
            propertyTitle: prop.title,
            context: 'Tenant',
          });
        }
      }
    } else if (role === 'admin' || role === 'law_reviewer') {
      // Admin/law_reviewer can only message other admins and law_reviewers (not tenants/landlords/PMs)
      const authorityUsers = await User.find({
        _id: { $ne: userId },
        isActive: true,
        role: { $in: ['admin', 'law_reviewer'] },
      })
        .select('name email role profilePhoto')
        .limit(100);
      contacts = authorityUsers.map(u => ({
        user: u,
        propertyId: null,
        propertyTitle: 'Direct Message',
        context: u.role.replace('_', ' '),
      }));
    }

    // Deduplicate by user._id + propertyId combo
    const seen = new Set();
    contacts = contacts.filter(c => {
      const key = `${c.user?._id}-${c.propertyId}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });

    res.json(contacts);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Landlord analytics — revenue, occupancy, payment health, renewals
// @route   GET /api/users/landlord-analytics
// @access  Private (landlord only)
const getLandlordAnalytics = async (req, res) => {
  try {
    const landlordId = req.user._id;
    const now = new Date();

    const sixMonthsAgo = new Date(now);
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

    const monthlyRevenue = await Payment.aggregate([
      { $match: { landlord: landlordId, status: 'paid', type: 'rent', paidAt: { $gte: sixMonthsAgo } } },
      {
        $group: {
          _id: { year: { $year: '$paidAt' }, month: { $month: '$paidAt' } },
          total: { $sum: '$amount' },
          lateFeeTotal: { $sum: '$lateFeeAmount' },
          count: { $sum: 1 },
        },
      },
      { $sort: { '_id.year': 1, '_id.month': 1 } },
    ]);

    const activeAgreements = await Agreement.find({ landlord: landlordId, status: 'active' })
      .select('rentSchedule financials term property tenant')
      .populate('property', 'title')
      .populate('tenant', 'name');

    let paid = 0, pending = 0, overdue = 0, lateFeeCollected = 0;
    activeAgreements.forEach(a => {
      (a.rentSchedule || []).forEach(entry => {
        if (entry.status === 'paid') paid++;
        else if (entry.status === 'pending') pending++;
        else if (['overdue', 'late_fee_applied'].includes(entry.status)) overdue++;
        if (entry.lateFeeApplied) lateFeeCollected += (entry.lateFeeAmount || 0);
      });
    });

    const [totalProperties, leasedProperties] = await Promise.all([
      Property.countDocuments({ owner: landlordId }),
      Agreement.countDocuments({ landlord: landlordId, status: 'active' }),
    ]);

    const in90Days = new Date(now);
    in90Days.setDate(in90Days.getDate() + 90);

    const expiringLeases = await Agreement.find({
      landlord: landlordId,
      status: 'active',
      'term.endDate': { $gte: now, $lte: in90Days },
    })
      .select('term financials')
      .populate('property', 'title address')
      .populate('tenant', 'name email')
      .sort('term.endDate');

    const agreementStatusRaw = await Agreement.aggregate([
      { $match: { landlord: landlordId } },
      { $group: { _id: '$status', count: { $sum: 1 } } },
    ]);
    const agreementStatus = agreementStatusRaw.reduce((acc, s) => { acc[s._id] = s.count; return acc; }, {});

    const lifetimeRevenue = await Payment.aggregate([
      { $match: { landlord: landlordId, status: 'paid', type: 'rent' } },
      { $group: { _id: null, total: { $sum: '$amount' } } },
    ]);

    res.json({
      monthlyRevenue,
      paymentHealth: { paid, pending, overdue },
      lateFeeCollected,
      occupancy: { total: totalProperties, leased: leasedProperties, vacant: Math.max(0, totalProperties - leasedProperties) },
      expiringLeases,
      agreementStatus,
      lifetimeRevenue: lifetimeRevenue[0]?.total || 0,
      activeTenantsCount: activeAgreements.length,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Create or reuse Stripe Connect onboarding link for landlord payouts
// @route   POST /api/users/stripe-connect/onboard
// @access  Private (Landlord)
const createStripeConnectOnboarding = async (req, res) => {
  try {
    if (req.user.role !== 'landlord') {
      return res.status(403).json({ message: 'Only landlords can connect Stripe payouts' });
    }

    if (!process.env.STRIPE_SECRET_KEY) {
      return res.status(503).json({ message: 'Stripe is not configured on the server' });
    }

    const user = await User.findById(req.user._id).select('name email role stripeId');
    if (!user) return res.status(404).json({ message: 'User not found' });

    const stripe = getStripeClient();
    let stripeId = user.stripeId;

    if (!stripeId) {
      const account = await stripe.accounts.create({
        type: 'express',
        email: user.email,
        business_type: 'individual',
        capabilities: {
          card_payments: { requested: true },
          transfers: { requested: true },
        },
        metadata: {
          userId: user._id.toString(),
          role: user.role,
        },
      });

      stripeId = account.id;
      user.stripeId = stripeId;
      await user.save();
    }

    const clientUrl = process.env.CLIENT_URL || 'http://localhost:3000';
    const accountLink = await stripe.accountLinks.create({
      account: stripeId,
      refresh_url: `${clientUrl}/dashboard/profile?stripe=refresh`,
      return_url: `${clientUrl}/dashboard/profile?stripe=return`,
      type: 'account_onboarding',
    });

    res.json({ url: accountLink.url, stripeId });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get Stripe Connect status for landlord payout account
// @route   GET /api/users/stripe-connect/status
// @access  Private (Landlord)
const getStripeConnectStatus = async (req, res) => {
  try {
    if (req.user.role !== 'landlord') {
      return res.status(403).json({ message: 'Only landlords can view Stripe payout status' });
    }

    const user = await User.findById(req.user._id).select('stripeId');
    if (!user) return res.status(404).json({ message: 'User not found' });

    if (!user.stripeId) {
      return res.json({
        connected: false,
        stripeId: null,
        onboardingComplete: false,
        detailsSubmitted: false,
        payoutsEnabled: false,
        chargesEnabled: false,
        requirementsDue: [],
      });
    }

    if (!process.env.STRIPE_SECRET_KEY) {
      return res.status(503).json({ message: 'Stripe is not configured on the server' });
    }

    const stripe = getStripeClient();
    const account = await stripe.accounts.retrieve(user.stripeId);
    const onboardingComplete = !!(account.details_submitted && account.payouts_enabled);

    res.json({
      connected: onboardingComplete,
      stripeId: user.stripeId,
      onboardingComplete,
      detailsSubmitted: !!account.details_submitted,
      payoutsEnabled: !!account.payouts_enabled,
      chargesEnabled: !!account.charges_enabled,
      requirementsDue: account.requirements?.currently_due || [],
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};


// ─── Document Verification Submission ────────────────────────────────────────
async function submitVerificationDocuments(req, res) {
  try {
    const user = await User.findById(req.user._id);
    if (!user) return res.status(404).json({ message: 'User not found' });
    if (!['landlord', 'property_manager'].includes(user.role)) {
      return res.status(403).json({ message: 'Only landlords and property managers can submit verification documents' });
    }
    if (user.verificationStatus === 'approved') {
      return res.status(400).json({ message: 'Your documents are already verified' });
    }

    const { documents } = req.body; // Array of { url, documentType, originalName }
    if (!Array.isArray(documents) || documents.length === 0) {
      return res.status(400).json({ message: 'At least one document is required' });
    }

    user.verificationDocuments = documents.map(d => ({
      url: d.url,
      documentType: d.documentType || 'cnic',
      originalName: d.originalName || '',
      uploadedAt: new Date(),
    }));
    user.verificationStatus = 'pending';
    user.documentsVerified = false;
    await user.save();

    res.json({ message: 'Documents submitted successfully. Pending admin review.' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
}

// @desc    Get a lightweight dashboard summary (avoids fetching full data sets)
// @route   GET /api/users/dashboard-summary
// @access  Private
const getDashboardSummary = async (req, res) => {
  try {
    const { role, _id: userId } = req.user;
    const Agreement = require('../models/Agreement');
    const Payment = require('../models/Payment');
    const Property = require('../models/Property');
    const Dispute = require('../models/Dispute');
    const MaintenanceRequest = require('../models/MaintenanceRequest');
    const Offer = require('../models/Offer');

    let agreementQuery, propertyQuery, paymentQuery;

    if (role === 'tenant') {
      agreementQuery = { tenant: userId };
      paymentQuery = { tenant: userId };
    } else if (role === 'landlord') {
      agreementQuery = { landlord: userId };
      propertyQuery = { landlord: userId };
      paymentQuery = { landlord: userId };
    } else if (role === 'property_manager') {
      const managedProps = await Property.find({ managedBy: userId }).select('_id');
      const propIds = managedProps.map(p => p._id);
      agreementQuery = { property: { $in: propIds } };
      paymentQuery = { property: { $in: propIds } };
      propertyQuery = { managedBy: userId };
    } else {
      // admin / law_reviewer
      agreementQuery = {};
      propertyQuery = {};
      paymentQuery = {};
    }

    const [
      activeAgreements,
      pendingOffers,
      recentPayments,
      propertyCount,
      pendingDisputes,
      pendingMaintenance,
      overduePayments,
      pendingApprovalPayments,
      pendingApprovalAmountAgg,
    ] = await Promise.all([
      Agreement.countDocuments({ ...agreementQuery, status: 'active' }),
      Offer.countDocuments({ ...(role === 'landlord' ? { landlord: userId } : role === 'tenant' ? { tenant: userId } : {}), status: { $in: ['pending', 'countered'] } }),
      Payment.find(paymentQuery)
        .select('amount status type paidAt dueDate property')
        .populate('property', 'title')
        .sort('-paidAt')
        .limit(5),
      propertyQuery ? Property.countDocuments(propertyQuery) : 0,
      Dispute.countDocuments({ ...(role === 'tenant' ? { raisedBy: userId } : role === 'landlord' ? { property: { $in: (await Property.find({ landlord: userId }).select('_id')).map(p => p._id) } } : {}), status: { $in: ['open', 'under_review'] } }),
      MaintenanceRequest.countDocuments({ ...(role === 'tenant' ? { tenant: userId } : role === 'landlord' ? { property: { $in: (await Property.find({ landlord: userId }).select('_id')).map(p => p._id) } } : {}), status: { $in: ['pending', 'in_progress'] } }),
      Payment.countDocuments({ ...paymentQuery, status: { $in: ['failed', 'overdue'] } }),
      Payment.countDocuments({ ...paymentQuery, status: 'pending_approval' }),
      Payment.aggregate([
        { $match: { ...paymentQuery, status: 'pending_approval' } },
        {
          $group: {
            _id: null,
            total: { $sum: { $ifNull: ['$landlordPayoutAmount', '$amount'] } },
          },
        },
      ]),
    ]);

    // Recent agreements (just a few for the overview)
    const recentAgreements = await Agreement.find(agreementQuery)
      .select('status property tenant landlord term financials rentSchedule')
      .populate('property', 'title address')
      .populate('tenant', 'name email')
      .populate('landlord', 'name email')
      .sort('-createdAt')
      .limit(5);

    res.json({
      counts: {
        activeAgreements,
        pendingOffers,
        propertyCount,
        pendingDisputes,
        pendingMaintenance,
        overduePayments,
        pendingApprovalPayments,
        pendingApprovalAmount: pendingApprovalAmountAgg[0]?.total || 0,
      },
      recentPayments,
      recentAgreements,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
}
module.exports = {
  getUserByEmail,
  getProfile,
  getMe,
  updateProfile,
  updatePreferences,
  getContacts,
  getLandlordAnalytics,
  submitVerificationDocuments,
  getDashboardSummary,
  createStripeConnectOnboarding,
  getStripeConnectStatus,
};
