const User = require('../models/User');
const Property = require('../models/Property');
const Agreement = require('../models/Agreement');
const Payment = require('../models/Payment');
const Clause = require('../models/Clause');
const MaintenanceRequest = require('../models/MaintenanceRequest');
const logger = require('../utils/logger');
const { getPlatformBranding, upsertPlatformBranding } = require('../utils/platformSettings');

function getStripeClient() {
  return require('stripe')(process.env.STRIPE_SECRET_KEY);
}

// Revenue amounts for MRR calculation (cents). Sourced from env vars so they
// stay in sync with the billing plans without any hardcoded numbers here.
const MRR_CENTS = {
  pro: parseInt(process.env.PLAN_PRICE_PRO_CENTS || '1500', 10),
  enterprise: parseInt(process.env.PLAN_PRICE_ENTERPRISE_CENTS || '3000', 10),
};

// @desc    Get platform-wide stats
// @route   GET /api/admin/stats
// @access  Private (Admin)
const getStats = async (req, res) => {
  try {
    // Revenue approximations for stats calculation (not Stripe price IDs)
    const PLAN_REVENUE = MRR_CENTS; // Pro=$15/mo, Enterprise=$30/mo
    const landlordFilter = { role: 'landlord' };

    const [
      totalUsers,
      totalFreeLandlords,
      totalPro,
      totalEnterprise,
      totalProperties,
      totalAgreements,
      activeAgreements,
      pendingAgreements,
      expiredAgreements,
      openMaintenanceRequests,
    ] = await Promise.all([
      User.countDocuments(),
      User.countDocuments({
        ...landlordFilter,
        $or: [{ subscriptionTier: 'free' }, { subscriptionTier: null }, { subscriptionTier: { $exists: false } }],
      }),
      User.countDocuments({ ...landlordFilter, subscriptionTier: 'pro' }),
      User.countDocuments({ ...landlordFilter, subscriptionTier: 'enterprise' }),
      Property.countDocuments(),
      Agreement.countDocuments(),
      Agreement.countDocuments({ status: 'active' }),
      Agreement.countDocuments({ status: { $in: ['draft', 'sent', 'signed'] } }),
      Agreement.countDocuments({ status: 'expired' }),
      MaintenanceRequest.countDocuments({ status: { $in: ['open', 'in_progress'] } }),
    ]);

    // Divide by 100 to convert from cents to dollars before sending to client
    const monthlySubscriptionRevenue =
      Math.round(((totalPro * PLAN_REVENUE.pro) + (totalEnterprise * PLAN_REVENUE.enterprise)) / 100);

    const usersBySubscription = await User.aggregate([
      { $match: landlordFilter },
      {
        $project: {
          normalizedTier: {
            $toLower: { $ifNull: ['$subscriptionTier', 'free'] },
          },
        },
      },
      {
        $group: {
          _id: {
            $cond: [
              { $in: ['$normalizedTier', ['free', 'pro', 'enterprise']] },
              '$normalizedTier',
              'free',
            ],
          },
          count: { $sum: 1 },
        },
      },
      { $sort: { count: -1 } },
    ]);

    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

    const agreementsByMonth = await Agreement.aggregate([
      { $match: { createdAt: { $gte: sixMonthsAgo } } },
      {
        $group: {
          _id: { year: { $year: '$createdAt' }, month: { $month: '$createdAt' } },
          count: { $sum: 1 },
        },
      },
      { $sort: { '_id.year': 1, '_id.month': 1 } },
    ]);

    res.json({
      totals: {
        users: totalUsers,
        pro: totalPro,
        enterprise: totalEnterprise,
        free: totalFreeLandlords,
        properties: totalProperties,
        agreements: totalAgreements,
        activeAgreements,
        pendingAgreements,
        expiredAgreements,
        openMaintenanceRequests,
      },
      monthlySubscriptionRevenue,
      usersBySubscription,
      agreementsByMonth,
      generatedAt: new Date().toISOString(),
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};


// @desc    Get all users with filtering
// @route   GET /api/admin/users
// @access  Private (Admin)
const getUsers = async (req, res) => {
  try {
    const { role, isActive, search, page = 1, limit = 20 } = req.query;
    const filter = {};

    if (role) filter.role = role;
    if (isActive !== undefined) filter.isActive = isActive === 'true';
    if (search) {
      filter.$or = [
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
      ];
    }

    const skip = (Number(page) - 1) * Number(limit);

    const [users, total] = await Promise.all([
      User.find(filter)
        .select('-password -otpCode -otpExpiry -fcmToken -passwordResetToken -emailVerificationToken')
        .sort('-createdAt')
        .skip(skip)
        .limit(Number(limit)),
      User.countDocuments(filter),
    ]);

    res.json({
      users,
      pagination: { total, page: Number(page), pages: Math.ceil(total / Number(limit)) },
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};


// @desc    Get single user by ID
// @route   GET /api/admin/users/:id
// @access  Private (Admin)
const getUserById = async (req, res) => {
  try {
    const user = await User.findById(req.params.id)
      .select('-password -otpCode -otpExpiry -fcmToken -passwordResetToken -emailVerificationToken');

    if (!user) return res.status(404).json({ message: 'User not found' });

    const [agreements, properties] = await Promise.all([
      Agreement.find({ $or: [{ landlord: user._id }, { tenant: user._id }] })
        .select('status term financials property')
        .populate('property', 'title'),
      Property.find({ landlord: user._id }).select('title status isListed'),
    ]);

    res.json({ user, agreements, properties });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};


// @desc    Ban or unban a user
// @route   PUT /api/admin/users/:id/ban
// @access  Private (Admin)
const toggleUserBan = async (req, res) => {
  try {
    const user = await User.findById(req.params.id);

    if (!user) return res.status(404).json({ message: 'User not found' });

    if (user._id.toString() === req.user._id.toString()) {
      return res.status(400).json({ message: 'You cannot ban your own account' });
    }

    user.isActive = !user.isActive;
    await user.save();

    res.json({
      message: user.isActive ? 'User account reactivated' : 'User account suspended',
      isActive: user.isActive,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};


// @desc    Change a user's role
// @route   PUT /api/admin/users/:id/role
// @access  Private (Admin)
const changeUserRole = async (req, res) => {
  try {
    const { role } = req.body;
    const validRoles = ['landlord', 'tenant', 'admin', 'property_manager', 'law_reviewer'];

    if (!validRoles.includes(role)) {
      return res.status(400).json({ message: 'Invalid role' });
    }

    const user = await User.findByIdAndUpdate(
      req.params.id,
      { role },
      { returnDocument: 'after' }
    ).select('-password');

    if (!user) return res.status(404).json({ message: 'User not found' });

    res.json({ message: `Role updated to ${role}`, user });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};


// @desc    Get all agreements platform-wide
// @route   GET /api/admin/agreements
// @access  Private (Admin)
// @query   status= | search= (landlord/tenant/property name) | page= | limit=
const getAllAgreements = async (req, res) => {
  try {
    const { status, search, page = 1, limit = 50 } = req.query;
    const safeLimit = Math.min(200, Math.max(1, Number(limit)));
    const filter = {};
    if (status) filter.status = status;

    const agreements = await Agreement.find(filter)
      .populate('landlord', 'name email')
      .populate('tenant', 'name email')
      .populate('property', 'title address')
      .sort('-createdAt')
      .limit(safeLimit);

    let result = agreements;
    if (search) {
      const q = search.toLowerCase();
      result = agreements.filter((a) =>
        a.landlord?.name?.toLowerCase().includes(q) ||
        a.tenant?.name?.toLowerCase().includes(q) ||
        a.property?.title?.toLowerCase().includes(q)
      );
    }

    res.json(result);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};


// @desc    Get platform-wide audit log (from all agreements)
// @route   GET /api/admin/audit-logs
// @access  Private (Admin)
const getAuditLogs = async (req, res) => {
  try {
    const { page = 1, limit = 50, action } = req.query;
    const skip = (Number(page) - 1) * Number(limit);

    const facetResult = await Agreement.aggregate([
      { $unwind: '$auditLog' },
      ...(action ? [{ $match: { 'auditLog.action': action } }] : []),
      { $sort: { 'auditLog.timestamp': -1 } },
      {
        $facet: {
          logs: [
            { $skip: skip },
            { $limit: Number(limit) },
            {
              $project: {
                action: '$auditLog.action',
                actor: '$auditLog.actor',
                timestamp: '$auditLog.timestamp',
                ipAddress: '$auditLog.ipAddress',
                details: '$auditLog.details',
                agreementId: '$_id',
              },
            },
          ],
          totalCount: [{ $count: 'count' }],
        },
      },
    ]);

    const logs = facetResult[0]?.logs || [];
    const total = facetResult[0]?.totalCount[0]?.count || 0;

    res.json({
      logs,
      pagination: {
        total,
        page: Number(page),
        limit: Number(limit),
        totalPages: Math.ceil(total / Number(limit)),
      },
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};


// ─── Clause / Template Management ─────────────────────────────────────────────

// @desc    Get all clauses
// @route   GET /api/admin/clauses
// @access  Private (Admin, Law Reviewer)
const getClauses = async (req, res) => {
  try {
    const { category, isApproved, isArchived = false } = req.query;
    const filter = { isArchived: isArchived === 'true' };

    if (category) filter.category = category;
    if (isApproved !== undefined) filter.isApproved = isApproved === 'true';

    const clauses = await Clause.find(filter)
      .populate('createdBy', 'name email')
      .populate('approvedBy', 'name email')
      .sort('-createdAt');

    res.json(clauses);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};


// @desc    Create a new clause template
// @route   POST /api/admin/clauses
// @access  Private (Admin, Law Reviewer)
const createClause = async (req, res) => {
  try {
    const { title, body, category, jurisdiction, isDefault, condition } = req.body;

    const clause = await Clause.create({
      title,
      body,
      category: category || 'general',
      jurisdiction: jurisdiction || 'Pakistan',
      isDefault: isDefault || false,
      condition: condition || null,    // [FIX #4]
      createdBy: req.user._id,
    });

    res.status(201).json(clause);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};


// @desc    Approve or reject a clause
// @route   PUT /api/admin/clauses/:id/approve
// @access  Private (Admin, Law Reviewer)
const reviewClause = async (req, res) => {
  try {
    const { approved, rejectionReason } = req.body;

    const clause = await Clause.findById(req.params.id);
    if (!clause) return res.status(404).json({ message: 'Clause not found' });

    clause.isApproved = approved;
    clause.approvedBy = approved ? req.user._id : null;
    clause.approvedAt = approved ? new Date() : null;
    clause.rejectionReason = approved ? '' : (rejectionReason || 'Not approved');

    await clause.save();
    res.json(clause);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};


// @desc    Archive a clause
// @route   PUT /api/admin/clauses/:id/archive
// @access  Private (Admin)
const archiveClause = async (req, res) => {
  try {
    const clause = await Clause.findByIdAndUpdate(
      req.params.id,
      { isArchived: true, isLatestVersion: false },
      { returnDocument: 'after' }
    );
    if (!clause) return res.status(404).json({ message: 'Clause not found' });
    res.json({ message: 'Clause archived', clause });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Restore an archived clause
// @route   PUT /api/admin/clauses/:id/restore
// @access  Private (Admin)
const restoreClause = async (req, res) => {
  try {
    const clause = await Clause.findByIdAndUpdate(
      req.params.id,
      { isArchived: false, isLatestVersion: true },
      { returnDocument: 'after' }
    );
    if (!clause) return res.status(404).json({ message: 'Clause not found' });
    res.json({ message: 'Clause restored', clause });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};


// @desc    Get all properties with tenant info
// @route   GET /api/admin/properties
// @access  Private (Admin)
// @query   search= (title, landlord name, city)
const getAllProperties = async (req, res) => {
  try {
    const { search } = req.query;
    const filter = {};
    if (search) {
      const re = { $regex: search, $options: 'i' };
      filter.$or = [
        { title: re },
        { 'address.city': re },
      ];
    }

    const properties = await Property.find(filter)
      .populate('landlord', 'name email')
      .populate('managedBy', 'name email')
      .sort({ createdAt: -1 });

    const propIds = properties.map((p) => p._id);
    const activeAgreements = await Agreement.find({
      property: { $in: propIds },
      status: 'active',
    }).populate('tenant', 'name email');

    const tenantMap = {};
    activeAgreements.forEach((ag) => {
      tenantMap[ag.property.toString()] = ag;
    });

    // If search also needs landlord/tenant name filtering (post-populate),
    // apply in memory since those are joined fields from populate.
    let result = properties.map((p) => ({
      ...p.toObject(),
      activeAgreement: tenantMap[p._id.toString()] || null,
    }));

    if (search) {
      const q = search.toLowerCase();
      result = result.filter((p) =>
        (!search) ||
        p.title?.toLowerCase().includes(q) ||
        p.landlord?.name?.toLowerCase().includes(q) ||
        p.address?.city?.toLowerCase().includes(q) ||
        p.activeAgreement?.tenant?.name?.toLowerCase().includes(q)
      );
    }

    res.json(result);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};


// @desc    Kick tenant from property (terminate agreement)
// @route   POST /api/admin/properties/:id/kick-tenant
// @access  Private (Admin)
const kickTenantFromProperty = async (req, res) => {
  try {
    const { reason } = req.body;
    const propertyId = req.params.id;

    const agreement = await Agreement.findOne({
      property: propertyId,
      status: 'active',
    })
      .populate('tenant', 'name email')
      .populate('property', 'title');

    if (!agreement) {
      return res.status(404).json({ message: 'No active tenant found for this property' });
    }

    agreement.status = 'terminated';
    agreement.auditLog.push({
      action: 'TERMINATED_BY_ADMIN',
      actor: req.user._id,
      ipAddress: req.ip,
      details: reason || 'Terminated by administrator',
    });
    await agreement.save();

    await Property.findByIdAndUpdate(propertyId, { status: 'vacant', isListed: false });

    res.json({ message: `Tenant ${agreement.tenant?.name} has been removed from ${agreement.property?.title}` });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};


// @desc    Admin deep analytics — revenue, churn, growth, disputes, maintenance
// @route   GET /api/admin/analytics
// @access  Private (Admin)
const getAdminAnalytics = async (req, res) => {
  try {
    const now = new Date();
    const sixMonthsAgo = new Date(now);
    sixMonthsAgo.setMonth(now.getMonth() - 6);

    const [
      monthlyRentRevenue,
      totalRentRevenue,
      revenueByGateway,
      expiredLast6,
      createdLast6,
      userGrowth,
      disputeStats,
      maintenanceStats,
    ] = await Promise.all([
      Payment.aggregate([
        { $match: { status: 'paid', type: 'rent', paidAt: { $gte: sixMonthsAgo } } },
        { $group: { _id: { year: { $year: '$paidAt' }, month: { $month: '$paidAt' } }, total: { $sum: '$amount' }, count: { $sum: 1 } } },
        { $sort: { '_id.year': 1, '_id.month': 1 } },
      ]),
      Payment.aggregate([
        { $match: { status: 'paid', type: 'rent' } },
        { $group: { _id: null, total: { $sum: '$amount' } } },
      ]),
      Payment.aggregate([
        { $match: { status: 'paid' } },
        { $group: { _id: '$gateway', total: { $sum: '$amount' }, count: { $sum: 1 } } },
        { $sort: { total: -1 } },
      ]),
      Agreement.countDocuments({ status: { $in: ['expired', 'terminated'] }, updatedAt: { $gte: sixMonthsAgo } }),
      Agreement.countDocuments({ createdAt: { $gte: sixMonthsAgo } }),
      User.aggregate([
        { $match: { createdAt: { $gte: sixMonthsAgo } } },
        { $group: { _id: { year: { $year: '$createdAt' }, month: { $month: '$createdAt' } }, count: { $sum: 1 } } },
        { $sort: { '_id.year': 1, '_id.month': 1 } },
      ]),
      require('../models/Dispute').aggregate([
        { $group: { _id: '$status', count: { $sum: 1 } } },
      ]),
      MaintenanceRequest.aggregate([
        { $group: { _id: '$status', count: { $sum: 1 } } },
      ]),
    ]);

    const churnRate = createdLast6 > 0 ? Math.round((expiredLast6 / createdLast6) * 100) : 0;

    res.json({
      monthlyRentRevenue,
      totalRentRevenue: totalRentRevenue[0]?.total || 0,
      revenueByGateway,
      churnRate,
      expiredLast6,
      createdLast6,
      userGrowth,
      disputeStats: disputeStats.reduce((a, d) => { a[d._id] = d.count; return a; }, {}),
      maintenanceStats: maintenanceStats.reduce((a, d) => { a[d._id] = d.count; return a; }, {}),
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};


// @desc    Paginated list of all users with billing / subscription details
// @route   GET /api/admin/billing/users
// @access  Private (Admin)
// @query   page=1 | limit=25 | tier=free|pro|enterprise | search=<name or email>
// [FIX #6]
const getBillingUsers = async (req, res) => {
  try {
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const limit = Math.min(100, parseInt(req.query.limit) || 25);
    const skip = (page - 1) * limit;
    const { tier, search } = req.query;

    // Only landlords have subscriptions
    const filter = { role: 'landlord' };

    if (tier && ['free', 'pro', 'enterprise'].includes(tier)) {
      if (tier === 'free') {
        filter.$or = [
          { subscriptionTier: 'free' },
          { subscriptionTier: { $exists: false } },
          { subscriptionTier: null },
        ];
      } else {
        filter.subscriptionTier = tier;
      }
    }

    if (search) {
      const regex = { $regex: search, $options: 'i' };
      filter.$and = [
        { role: 'landlord' },
        { $or: [{ name: regex }, { email: regex }] },
      ];
      delete filter.role; // moved into $and
    }

    const [users, total] = await Promise.all([
      User.find(filter)
        .select('name email subscriptionTier createdAt isActive')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit)
        .lean(),
      User.countDocuments(filter),
    ]);

    const summarizeTiers = async (matchFilter) => {
      const grouped = await User.aggregate([
        { $match: matchFilter },
        {
          $project: {
            normalizedTier: {
              $toLower: { $ifNull: ['$subscriptionTier', 'free'] },
            },
          },
        },
        {
          $group: {
            _id: {
              $cond: [
                { $in: ['$normalizedTier', ['free', 'pro', 'enterprise']] },
                '$normalizedTier',
                'free',
              ],
            },
            count: { $sum: 1 },
          },
        },
      ]);

      const summary = { free: 0, pro: 0, enterprise: 0 };
      grouped.forEach((row) => {
        if (row._id && summary[row._id] !== undefined) {
          summary[row._id] = row.count;
        }
      });

      return {
        ...summary,
        subscribed: summary.pro + summary.enterprise,
        totalMRR: Math.round(((summary.pro * MRR_CENTS.pro) + (summary.enterprise * MRR_CENTS.enterprise)) / 100),
      };
    };

    const [summaryAll, summaryFiltered] = await Promise.all([
      summarizeTiers({ role: 'landlord' }),
      summarizeTiers(filter),
    ]);

    res.json({
      users,
      pagination: {
        total,
        page,
        limit,
        pages: Math.ceil(total / limit),
      },
      summary: summaryFiltered,
      summaryAll,
    });
  } catch (error) {
    logger.error('getBillingUsers error', { err: error.message });
    res.status(500).json({ message: 'Server error' });
  }
};


// @desc    List payments for admin approval queue
// @route   GET /api/admin/payments
// @access  Private (Admin)
const getPaymentsForApproval = async (req, res) => {
  try {
    const page = Math.max(1, Number(req.query.page) || 1);
    const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 25));
    const skip = (page - 1) * limit;
    const status = String(req.query.status || 'pending_approval').trim();

    const filter = {
      type: { $in: ['initial', 'rent'] },
    };

    if (status !== 'all') {
      filter.status = status;
    }

    if (req.query.landlordId) {
      filter.landlord = req.query.landlordId;
    }

    const [payments, total, pendingTotals] = await Promise.all([
      Payment.find(filter)
        .populate('tenant', 'name email')
        .populate('landlord', 'name email stripeId')
        .populate('property', 'title address')
        .populate('agreement', 'financials term')
        .sort({ paidAt: -1, createdAt: -1 })
        .skip(skip)
        .limit(limit),
      Payment.countDocuments(filter),
      Payment.aggregate([
        { $match: { status: 'pending_approval', type: { $in: ['initial', 'rent'] } } },
        {
          $group: {
            _id: null,
            count: { $sum: 1 },
            tenantPaidTotal: { $sum: '$amount' },
            landlordPayoutTotal: { $sum: { $ifNull: ['$landlordPayoutAmount', '$amount'] } },
          },
        },
      ]),
    ]);

    const pendingSummary = pendingTotals[0] || {
      count: 0,
      tenantPaidTotal: 0,
      landlordPayoutTotal: 0,
    };

    res.json({
      payments,
      pagination: {
        total,
        page,
        limit,
        pages: Math.ceil(total / limit),
      },
      summary: {
        pendingCount: pendingSummary.count,
        pendingTenantPaidTotal: pendingSummary.tenantPaidTotal,
        pendingLandlordPayoutTotal: pendingSummary.landlordPayoutTotal,
      },
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};


// @desc    Approve a pending tenant payment and transfer landlord payout
// @route   PUT /api/admin/payments/:paymentId/approve
// @access  Private (Admin)
const approvePaymentForLandlord = async (req, res) => {
  try {
    if (!process.env.STRIPE_SECRET_KEY) {
      return res.status(503).json({ message: 'Stripe is not configured on the server' });
    }

    const payment = await Payment.findById(req.params.paymentId)
      .populate('landlord', 'name email stripeId')
      .populate('agreement', 'financials');

    if (!payment) {
      return res.status(404).json({ message: 'Payment not found' });
    }

    if (payment.status !== 'pending_approval') {
      return res.status(400).json({ message: 'Payment is not pending admin approval' });
    }

    if (!payment.landlord?.stripeId) {
      return res.status(400).json({ message: 'Landlord has not connected a Stripe payout account' });
    }

    let payoutAmount = Number(payment.landlordPayoutAmount);
    if (!Number.isFinite(payoutAmount) || payoutAmount <= 0) {
      if (payment.type === 'initial') {
        payoutAmount = Number(payment.agreement?.financials?.rentAmount || 0);
      } else {
        payoutAmount = Number(payment.amount || 0);
      }
    }

    if (!Number.isFinite(payoutAmount) || payoutAmount <= 0) {
      return res.status(400).json({ message: 'Invalid payout amount for this payment' });
    }

    const payoutCents = Math.round(payoutAmount * 100);
    const currency = (process.env.STRIPE_CURRENCY || 'usd').toLowerCase();
    const stripe = getStripeClient();

    const transferParams = {
      amount: payoutCents,
      currency,
      destination: payment.landlord.stripeId,
      metadata: {
        paymentId: payment._id.toString(),
        agreementId: payment.agreement?._id?.toString() || '',
        landlordId: payment.landlord._id.toString(),
        approvedBy: req.user._id.toString(),
      },
    };

    if (payment.stripePaymentIntent) {
      try {
        const paymentIntent = await stripe.paymentIntents.retrieve(payment.stripePaymentIntent);
        if (paymentIntent?.latest_charge) {
          transferParams.source_transaction = paymentIntent.latest_charge;
        }
      } catch (intentErr) {
        logger.warn('Failed to retrieve payment intent for transfer source', {
          paymentId: payment._id.toString(),
          paymentIntent: payment.stripePaymentIntent,
          err: intentErr.message,
        });
      }
    }

    const transfer = await stripe.transfers.create(transferParams);

    payment.status = 'paid';
    payment.landlordPayoutAmount = payoutAmount;
    payment.adminApprovedBy = req.user._id;
    payment.adminApprovedAt = new Date();
    payment.stripeTransferId = transfer.id;

    const approvalNote = String(req.body?.notes || '').trim();
    if (approvalNote) {
      payment.notes = payment.notes
        ? `${payment.notes}\n[ADMIN_APPROVAL] ${approvalNote}`
        : `[ADMIN_APPROVAL] ${approvalNote}`;
    }

    await payment.save();

    res.json({
      message: 'Payment approved and landlord payout transferred',
      payment,
      transfer: {
        id: transfer.id,
        amount: transfer.amount / 100,
        currency: transfer.currency,
        destination: transfer.destination,
      },
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};



// ─── Clause Variable Definitions ──────────────────────────────────────────────
// @desc    Return the full list of available template variables for clause building
// @route   GET /api/admin/clauses/variables
// @access  Private (Admin, Law Reviewer)
//
// These variables exactly mirror the keys produced by clauseSubstitution.js
// buildVariableMap(), so what the admin sees in the UI is guaranteed to match
// what gets substituted when the PDF is generated. No DB query needed —
// the set of variables is static and tied to the Agreement schema.
const CLAUSE_VARIABLES = [
  // Parties
  { key: 'tenant_name', label: 'Tenant Name', group: 'Parties', description: 'Full legal name of the tenant' },
  { key: 'landlord_name', label: 'Landlord Name', group: 'Parties', description: 'Full legal name of the landlord' },
  // Property
  { key: 'property_title', label: 'Property Title', group: 'Property', description: 'Listing title of the property' },
  { key: 'property_address', label: 'Property Address', group: 'Property', description: 'Full street, city, and state address' },
  // Financials
  { key: 'rent_amount', label: 'Monthly Rent', group: 'Financials', description: 'Monthly rent amount' },
  { key: 'security_deposit', label: 'Security Deposit', group: 'Financials', description: 'Refundable security deposit' },
  { key: 'total_move_in', label: 'Total Move-in Cost', group: 'Financials', description: 'Total of first month rent and deposit' },
  { key: 'late_fee', label: 'Late Fee Amount', group: 'Financials', description: 'Penalty charged after grace period' },
  { key: 'late_fee_grace_days', label: 'Grace Period (Days)', group: 'Financials', description: 'Days before late fee applies' },
  { key: 'maintenance_fee', label: 'Maintenance Fee', group: 'Financials', description: 'Monthly service or maintenance charges' },
  // Term
  { key: 'start_date', label: 'Lease Start Date', group: 'Term', description: 'Commencement date of the lease' },
  { key: 'end_date', label: 'Lease End Date', group: 'Term', description: 'Expiration date of the lease' },
  { key: 'duration_months', label: 'Lease Duration', group: 'Term', description: 'Total length of lease in months' },
  // Policies
  { key: 'utilities_included', label: 'Utilities Policy', group: 'Policies', description: 'Whether utilities are included in rent' },
  { key: 'pet_allowed', label: 'Pet Policy', group: 'Policies', description: 'Whether pets are permitted' },
  { key: 'pet_deposit', label: 'Pet Deposit', group: 'Policies', description: 'Additional security deposit for pets' },
  { key: 'termination_policy', label: 'Termination Notice', group: 'Policies', description: 'Notice period required to end lease' },
  // System
  { key: 'current_date', label: 'Current Date', group: 'System', description: 'Date the document is generated' },
  { key: 'agreement_id', label: 'Agreement ID', group: 'System', description: 'Unique system identifier' },
];

const getClauseVariables = (req, res) => {
  res.json(CLAUSE_VARIABLES);
};

// @desc    Get platform branding settings
// @route   GET /api/admin/settings/branding
// @access  Private (Admin)
const getBrandingSettings = async (req, res) => {
  try {
    const branding = await getPlatformBranding({ force: true });
    res.json(branding);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Update platform branding settings
// @route   PUT /api/admin/settings/branding
// @access  Private (Admin)
const updateBrandingSettings = async (req, res) => {
  try {
    const { brandName, supportEmail, logoUrl, faviconUrl } = req.body || {};
    const updated = await upsertPlatformBranding({
      brandName,
      supportEmail,
      logoUrl,
      faviconUrl,
      updatedBy: req.user?._id || null,
    });
    res.json({ message: 'Branding settings updated', ...updated });
  } catch (error) {
    const code = error.statusCode || 500;
    res.status(code).json({ message: error.message || 'Failed to update branding settings' });
  }
};

// @desc    Public branding settings for frontend display
// @route   GET /api/settings/branding
// @access  Public
const getPublicBrandingSettings = async (_req, res) => {
  try {
    const branding = await getPlatformBranding();
    res.json(branding);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ─── Document Verification Admin Functions ─────────────────────────────────
const { getTenantDocumentUrl, isS3Configured } = require('../utils/s3Service');

async function resolveDocUrls(docs = []) {
  if (!isS3Configured()) return docs;
  return Promise.all(docs.map(async (doc) => {
    const d = doc.toObject ? doc.toObject() : { ...doc };
    if (d.url && !d.url.startsWith('http')) {
      d.url = await getTenantDocumentUrl(d.url, 1800); // 30-min signed URL
    }
    return d;
  }));
}

// BUG-12 fix: declared above module.exports so these remain safe if ever
// converted to const arrow functions (hoisting would not apply to those).
async function getPendingVerifications(req, res) {
  try {
    const users = await User.find({ verificationStatus: 'pending' })
      .select('name email role verificationDocuments verificationStatus documentsVerified createdAt');
    const result = await Promise.all(users.map(async (u) => {
      const obj = u.toObject();
      obj.verificationDocuments = await resolveDocUrls(obj.verificationDocuments || []);
      return obj;
    }));
    res.json(result);
  } catch (err) { res.status(500).json({ message: err.message }); }
}

async function getApprovedVerifications(req, res) {
  try {
    const users = await User.find({ verificationStatus: 'approved' })
      .select('name email role verificationDocuments verificationStatus documentsVerified createdAt');
    const result = await Promise.all(users.map(async (u) => {
      const obj = u.toObject();
      obj.verificationDocuments = await resolveDocUrls(obj.verificationDocuments || []);
      return obj;
    }));
    res.json(result);
  } catch (err) { res.status(500).json({ message: err.message }); }
}

async function approveVerification(req, res) {
  try {
    const user = await User.findById(req.params.userId);
    if (!user) return res.status(404).json({ message: 'User not found' });
    user.verificationStatus = 'approved';
    user.documentsVerified = true;
    await user.save();
    res.json({ message: 'User documents approved successfully' });
  } catch (err) { res.status(500).json({ message: err.message }); }
}

async function rejectVerification(req, res) {
  try {
    const user = await User.findById(req.params.userId);
    if (!user) return res.status(404).json({ message: 'User not found' });
    user.verificationStatus = 'rejected';
    user.documentsVerified = false;
    await user.save();
    res.json({ message: 'User documents rejected' });
  } catch (err) { res.status(500).json({ message: err.message }); }
}

module.exports = {
  getStats,
  getUsers,
  getUserById,
  toggleUserBan,
  changeUserRole,
  getAllAgreements,
  getAuditLogs,
  getClauses,
  createClause,
  reviewClause,
  archiveClause,
  restoreClause,
  getAllProperties,
  kickTenantFromProperty,
  getAdminAnalytics,
  getBillingUsers,
  getPaymentsForApproval,
  approvePaymentForLandlord,
  getPendingVerifications,
  getApprovedVerifications,
  approveVerification,
  rejectVerification,
  getClauseVariables,
  getBrandingSettings,
  updateBrandingSettings,
  getPublicBrandingSettings,
};