const User = require('../models/User');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const speakeasy = require('speakeasy');
const qrcode = require('qrcode');
const { generateAccessToken, generateRefreshToken } = require('../utils/generateToken');
const { validationResult } = require('express-validator');
const { sendEmail } = require('../utils/emailService');
const { sendOTP, verifyOTP, sendSMS } = require('../utils/smsService');

const resolveCookieSettings = () => {
  const envSecure = process.env.COOKIE_SECURE;
  const envSameSite = (process.env.COOKIE_SAMESITE || '').toLowerCase();
  const clientUrl = process.env.CLIENT_URL || '';

  const secure = envSecure === 'true'
    ? true
    : envSecure === 'false'
      ? false
      : clientUrl.startsWith('https://');

  const sameSite = ['none', 'lax', 'strict'].includes(envSameSite)
    ? envSameSite
    : (secure ? 'none' : 'lax');

  return { secure, sameSite };
};

// ─── [FIX] Exported so authRoutes.js OAuth callback uses the same cookie config
// This ensures sameSite:'none' is used consistently everywhere, which is
// required for cross-origin requests (Vercel frontend + nip.io API).
const setRefreshCookie = (res, token) => {
  const { secure, sameSite } = resolveCookieSettings();
  res.cookie('refreshToken', token, {
    httpOnly: true,
    secure,
    sameSite,
    maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days
    path: '/',
  });
};

// NEW-04: Non-HttpOnly role cookie so Next.js middleware can enforce
// role-based routing without a DB lookup on every request.
// It carries no security value on its own — the real auth gate is always the
// API's protect middleware; this is purely for client-side UX routing.
const setRoleCookie = (res, role) => {
  const { secure, sameSite } = resolveCookieSettings();
  res.cookie('userRole', role, {
    httpOnly: false,            // must be readable by Next.js middleware
    secure,
    sameSite,
    maxAge: 30 * 24 * 60 * 60 * 1000,
    path: '/',
  });
};

// ─── REGISTER ─────────────────────────────────────────────────────────────────
const registerUser = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ message: errors.array()[0].msg });

  const { name, email, password, role, phoneNumber } = req.body;
  const requestedRole = String(role || 'tenant').trim().toLowerCase();
  const selfRegisterRoles = ['tenant', 'landlord', 'property_manager'];
  if (!selfRegisterRoles.includes(requestedRole)) {
    return res.status(403).json({ message: 'Account creation is not allowed for this role' });
  }

  const userExists = await User.findOne({ email });
  if (userExists) return res.status(400).json({ message: 'User already exists' });

  const emailOtp = Math.floor(100000 + Math.random() * 900000).toString();
  const user = await User.create({
    name, email, password, role: requestedRole, phoneNumber,
    otpCode: emailOtp,
    otpExpiry: new Date(Date.now() + 24 * 60 * 60 * 1000),
    isVerified: false,
    isPhoneVerified: false,
  });

  if (user) {
    const accessToken = generateAccessToken(user._id);
    const refreshToken = generateRefreshToken(user._id);
    setRefreshCookie(res, refreshToken);
    setRoleCookie(res, user.role);
    await sendEmail(user.email, 'emailOTP', user.name, emailOtp);
    res.status(201).json({ _id: user._id, name: user.name, email: user.email, role: user.role, isVerified: false, token: accessToken });
  } else {
    res.status(400).json({ message: 'Invalid user data' });
  }
};

// ─── LOGIN ────────────────────────────────────────────────────────────────────
const loginUser = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ message: 'Invalid credentials format' });

  const { email, password } = req.body;
  const user = await User.findOne({ email }).select('+password');
  if (!user || !(await user.matchPassword(password))) {
    // Give OAuth-only users a specific error so they know to use Google/Facebook
    if (user && Array.isArray(user.authProviders) && !user.authProviders.includes('password')) {
      const provider = user.authProviders.find(p => p !== 'password') || 'social';
      return res.status(401).json({ message: 'OAUTH_ACCOUNT', provider });
    }
    return res.status(401).json({ message: 'Invalid email or password' });
  }
  // Admin and law_reviewer must use the super-login portal, not the normal portal
  if (['admin', 'law_reviewer'].includes(user.role)) {
    return res.status(401).json({ message: 'Invalid email or password' });
  }
  if (!user.isActive) return res.status(403).json({ message: 'Account suspended. Contact support.' });

  // Check email verification — ALL roles must verify
  if (!user.isVerified) {
    return res.status(403).json({ message: 'EMAIL_NOT_VERIFIED', email: user.email });
  }

  // Check phone verification — ALL roles must verify (skip Google placeholder)
  // No token is issued here — the real JWT is only minted inside verifyPhoneOTP
  // after the user proves they own the phone number.  The frontend drives the
  // send-otp / verify-otp flow using only the email address.
  if (!user.isPhoneVerified && user.phoneNumber !== '0000000000') {
    return res.status(403).json({ message: 'PHONE_NOT_VERIFIED', email: user.email, phoneNumber: user.phoneNumber });
  }

  user.lastLogin = new Date();
  await user.save();

  const accessToken = generateAccessToken(user._id);
  const refreshToken = generateRefreshToken(user._id);
  setRefreshCookie(res, refreshToken);
  setRoleCookie(res, user.role);

  res.json({ _id: user._id, name: user.name, email: user.email, role: user.role, isVerified: user.isVerified, isPhoneVerified: user.isPhoneVerified, twoFactorEnabled: user.twoFactorEnabled || false, token: accessToken });
};

// ─── SUPER LOGIN (Admin / Law Reviewer only) ──────────────────────────────────
const superLogin = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ message: 'Invalid credentials format' });

  const { email, password } = req.body;
  const user = await User.findOne({ email }).select('+password');
  if (!user || !(await user.matchPassword(password))) {
    return res.status(401).json({ message: 'Invalid email or password' });
  }

  // Super login is ONLY for admin and law_reviewer
  if (!['admin', 'law_reviewer'].includes(user.role)) {
    return res.status(401).json({ message: 'Invalid email or password' });
  }

  if (!user.isActive) return res.status(403).json({ message: 'Account suspended. Contact support.' });

  if (!user.isVerified) {
    return res.status(403).json({ message: 'EMAIL_NOT_VERIFIED', email: user.email });
  }

  if (!user.isPhoneVerified && user.phoneNumber !== '0000000000') {
    return res.status(403).json({ message: 'PHONE_NOT_VERIFIED', email: user.email, phoneNumber: user.phoneNumber });
  }

  user.lastLogin = new Date();
  await user.save();

  const accessToken = generateAccessToken(user._id);
  const refreshToken = generateRefreshToken(user._id);
  setRefreshCookie(res, refreshToken);
  setRoleCookie(res, user.role);

  res.json({ _id: user._id, name: user.name, email: user.email, role: user.role, isVerified: user.isVerified, isPhoneVerified: user.isPhoneVerified, twoFactorEnabled: user.twoFactorEnabled || false, token: accessToken });
};

// ─── REFRESH TOKEN ────────────────────────────────────────────────────────────
const refreshToken = async (req, res) => {
  const token = req.cookies?.refreshToken;
  if (!token) return res.status(401).json({ message: 'No refresh token' });

  try {
    const decoded = jwt.verify(token, process.env.JWT_REFRESH_SECRET);

    const user = await User.findById(decoded.id);
    if (!user) return res.status(401).json({ message: 'User not found' });

    // Reject banned / deactivated accounts on refresh too
    if (user.isActive === false) {
      return res.status(403).json({ message: 'Your account has been suspended. Please contact support.' });
    }

    const newAccessToken = generateAccessToken(user._id);
    const newRefreshToken = generateRefreshToken(user._id);

    setRefreshCookie(res, newRefreshToken);
    setRoleCookie(res, user.role);

    res.json({ token: newAccessToken });

  } catch {
    res.status(401).json({ message: 'Refresh token expired' });
  }
};

// ─── LOGOUT ───────────────────────────────────────────────────────────────────
const logoutUser = (req, res) => {
  const { secure, sameSite } = resolveCookieSettings();
  // Clear cookie with same options it was set with, otherwise some browsers ignore it
  res.clearCookie('userRole');
  res.clearCookie('refreshToken', {
    httpOnly: true,
    secure,
    sameSite,
    path: '/',
  });
  res.json({ message: 'Logged out successfully' });
};

// ─── EMAIL VERIFICATION ────────────────────────────────────────────────────────
const verifyEmail = async (req, res) => {
  try {
    const { email, code } = req.body;
    if (!email || !code) return res.status(400).json({ message: 'Email and code required' });
    const user = await User.findOne({ email }).select('+otpCode +otpExpiry');
    if (!user) return res.status(400).json({ message: 'User not found' });
    if (user.isVerified) return res.json({ message: 'Email already verified' });
    if (!user.otpCode || user.otpCode !== code.toString()) return res.status(400).json({ message: 'Invalid verification code' });
    if (!user.otpExpiry || user.otpExpiry < new Date()) return res.status(400).json({ message: 'Verification code expired, please request a new one' });
    user.isVerified = true;
    user.otpCode = null;
    user.otpExpiry = null;
    await user.save();
    res.json({ message: 'Email verified successfully!' });
  } catch (error) { res.status(500).json({ message: error.message }); }
};

const resendVerification = async (req, res) => {
  try {
    const { email } = req.body;
    const user = await User.findOne({ email }).select('+otpCode +otpExpiry');
    if (!user) return res.status(404).json({ message: 'User not found' });
    if (user.isVerified) return res.status(400).json({ message: 'Already verified' });
    const emailOtp = Math.floor(100000 + Math.random() * 900000).toString();
    user.otpCode = emailOtp;
    user.otpExpiry = new Date(Date.now() + 24 * 60 * 60 * 1000);
    await user.save();
    await sendEmail(user.email, 'emailOTP', user.name, emailOtp);
    res.json({ message: 'Verification code resent' });
  } catch (error) { res.status(500).json({ message: error.message }); }
};

// ─── PASSWORD RESET ────────────────────────────────────────────────────────────
const forgotPassword = async (req, res) => {
  try {
    const { email } = req.body;
    const user = await User.findOne({ email });
    if (!user) return res.json({ message: 'If this email exists, a reset link has been sent.' });

    const resetToken = crypto.randomBytes(32).toString('hex');
    user.passwordResetToken = crypto.createHash('sha256').update(resetToken).digest('hex');
    user.passwordResetExpiry = new Date(Date.now() + 60 * 60 * 1000);
    await user.save();

    const resetUrl = `${process.env.CLIENT_URL}/reset-password?token=${resetToken}`;
    await sendEmail(user.email, 'passwordReset', user.name, resetUrl);
    res.json({ message: 'If this email exists, a reset link has been sent.' });
  } catch (error) { res.status(500).json({ message: error.message }); }
};

const resetPassword = async (req, res) => {
  try {
    const { token, password } = req.body;
    if (!token || !password) return res.status(400).json({ message: 'Token and password required' });
    const hashedToken = crypto.createHash('sha256').update(token).digest('hex');
    const user = await User.findOne({ passwordResetToken: hashedToken, passwordResetExpiry: { $gt: new Date() } });
    if (!user) return res.status(400).json({ message: 'Reset link invalid or expired' });
    user.password = password;
    user.passwordResetToken = null;
    user.passwordResetExpiry = null;
    await user.save();
    res.json({ message: 'Password reset successfully.' });
  } catch (error) { res.status(500).json({ message: error.message }); }
};

// ─── OTP PHONE VERIFICATION ───────────────────────────────────────────────────
// Public — identified by email in the request body, no JWT required.
// Used by both the registration flow (after email verify) and the login flow
// (when the server returns PHONE_NOT_VERIFIED).
const sendPhoneOTP = async (req, res) => {
  try {
    // Support both authenticated (req.user from protect middleware on other routes)
    // and unauthenticated callers (email in body).
    const email = req.body.email || req.user?.email;
    if (!email) return res.status(400).json({ message: 'Email is required' });

    const user = await User.findOne({ email });
    if (!user) return res.status(404).json({ message: 'User not found' });
    if (!user.phoneNumber) return res.status(400).json({ message: 'No phone number on your account' });
    if (user.isPhoneVerified) return res.status(400).json({ message: 'Phone already verified' });

    // ── Cooldown: max one OTP per 60 seconds per user ─────────────────────
    const COOLDOWN_MS = 60 * 1000;
    if (user.otpSentAt && (Date.now() - new Date(user.otpSentAt).getTime()) < COOLDOWN_MS) {
      const secondsLeft = Math.ceil((COOLDOWN_MS - (Date.now() - new Date(user.otpSentAt).getTime())) / 1000);
      return res.status(429).json({
        message: `Please wait ${secondsLeft} seconds before requesting another OTP.`,
      });
    }

    const otpResult = await sendOTP(user.phoneNumber);
    // Support both legacy boolean `true` and new `{ success, reason }` return shapes
    const otpSuccess = otpResult === true || (otpResult && otpResult.success);
    const otpReason = otpResult && otpResult.reason;
    if (!otpSuccess) {
      if (otpReason === 'INVALID_FORMAT') {
        return res.status(400).json({
          message: 'Invalid phone number format. Please enter your number in international format (e.g. +14155551234).',
          code: 'INVALID_PHONE_FORMAT',
        });
      }
      return res.status(503).json({
        message: 'SMS service is temporarily unavailable. Please try again shortly.',
        code: 'OTP_SEND_FAILED',
      });
    }

    user.otpSentAt = new Date();
    await user.save();

    res.json({ message: 'OTP sent to your phone number' });
  } catch (error) { res.status(500).json({ message: error.message }); }
};

// Public — identified by email in body, no JWT required.
// On success this is the SINGLE place that issues the real access + refresh
// tokens for the email/password login + registration flows.
// The frontend must never write tokens to localStorage before reaching here.
const verifyPhoneOTP = async (req, res) => {
  try {
    const { email, code } = req.body;
    if (!email || !code) return res.status(400).json({ message: 'Email and OTP code are required' });

    const user = await User.findOne({ email });
    if (!user) return res.status(404).json({ message: 'User not found' });

    if (!user.isVerified) {
      return res.status(403).json({ message: 'Email must be verified before verifying phone' });
    }

    const valid = await verifyOTP(user.phoneNumber, code);
    if (!valid) return res.status(400).json({ message: 'Invalid or expired OTP code' });

    user.isPhoneVerified = true;
    user.lastLogin = new Date();
    await user.save();

    // Both verifications passed — now issue real tokens for the first time
    const accessToken = generateAccessToken(user._id);
    const refreshToken = generateRefreshToken(user._id);
    setRefreshCookie(res, refreshToken);
    setRoleCookie(res, user.role);

    res.json({
      _id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      isVerified: true,
      isPhoneVerified: true,
      twoFactorEnabled: user.twoFactorEnabled || false,
      token: accessToken,
    });
  } catch (error) { res.status(500).json({ message: error.message }); }
};

// ─── 2FA TOTP ─────────────────────────────────────────────────────────────────
const setup2FA = async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    const secret = speakeasy.generateSecret({ name: `RentifyPro (${user.email})`, length: 20 });
    user.twoFactorSecret = secret.base32;
    user.twoFactorEnabled = false;
    await user.save();
    const qrCode = await qrcode.toDataURL(secret.otpauth_url);
    res.json({ secret: secret.base32, qrCode, otpauthUrl: secret.otpauth_url });
  } catch (error) { res.status(500).json({ message: error.message }); }
};

const verify2FA = async (req, res) => {
  try {
    const { token } = req.body;
    if (!token) return res.status(400).json({ message: 'TOTP token required' });
    const user = await User.findById(req.user._id).select('+twoFactorSecret');
    if (!user.twoFactorSecret) return res.status(400).json({ message: 'Run 2FA setup first' });
    const ok = speakeasy.totp.verify({ secret: user.twoFactorSecret, encoding: 'base32', token, window: 1 });
    if (!ok) return res.status(400).json({ message: 'Invalid 2FA code' });
    user.twoFactorEnabled = true;
    await user.save();
    res.json({ message: '2FA enabled successfully.' });
  } catch (error) { res.status(500).json({ message: error.message }); }
};

const disable2FA = async (req, res) => {
  try {
    const { otpCode } = req.body;
    const user = await User.findById(req.user._id).select('+otpCode +otpExpiry');
    if (!user.twoFactorEnabled) return res.status(400).json({ message: '2FA is not enabled' });
    if (!otpCode) return res.status(400).json({ message: 'OTP code required' });
    if (!user.isOtpValid(otpCode)) return res.status(400).json({ message: 'Invalid or expired OTP code' });
    user.twoFactorEnabled = false;
    user.twoFactorSecret = null;
    user.otpCode = null;
    user.otpExpiry = null;
    await user.save();
    res.json({ message: '2FA disabled successfully' });
  } catch (error) { res.status(500).json({ message: error.message }); }
};

// ─── [FIX] send2FADisableOTP ──────────────────────────────────────────────────
// BUG: The old implementation stored a local OTP in user.otpCode, then called
// sendOTP() (Twilio Verify) which generates and sends its OWN separate code
// via Twilio's Verify service — completely different from what was stored.
// disable2FA checks user.isOtpValid(otpCode), which compares against the
// locally stored otpCode — so the two codes never matched → "Invalid OTP".
//
// FIX: For phone users, use sendSMS(…, 'otp', otp) to send the locally
// generated code directly via SMS, so it matches what isOtpValid() checks.
// Email path was already correct (it already sent the local `otp` value).
const send2FADisableOTP = async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    if (!user.twoFactorEnabled) return res.status(400).json({ message: '2FA is not enabled' });

    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    user.otpCode = otp;
    user.otpExpiry = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes
    await user.save();

    if (user.isPhoneVerified && user.phoneNumber) {
      // Use sendSMS with the 'otp' template so the locally stored code is what gets sent
      await sendSMS(user.phoneNumber, 'otp', otp);
      res.json({ message: 'OTP sent to your phone number', via: 'phone' });
    } else {
      await sendEmail(user.email, 'emailOTP', user.name, otp);
      res.json({ message: 'OTP sent to your email address', via: 'email' });
    }
  } catch (error) { res.status(500).json({ message: error.message }); }
};

const validate2FALogin = async (req, res) => {
  try {
    const { userId, token } = req.body;
    const user = await User.findById(userId).select('+twoFactorSecret');
    if (!user?.twoFactorEnabled) return res.status(400).json({ message: '2FA not enabled' });
    const ok = speakeasy.totp.verify({ secret: user.twoFactorSecret, encoding: 'base32', token, window: 1 });
    if (!ok) return res.status(400).json({ message: 'Invalid 2FA code' });
    const accessToken = generateAccessToken(user._id);
    const refreshToken = generateRefreshToken(user._id);
    setRefreshCookie(res, refreshToken);
    setRoleCookie(res, user.role);
    res.json({ _id: user._id, name: user.name, email: user.email, role: user.role, token: accessToken });
  } catch (error) { res.status(500).json({ message: error.message }); }
};

// ─── GOOGLE OAUTH ─────────────────────────────────────────────────────────────
// NOTE: Google OAuth callback is handled inline in authRoutes.js via
// passport.authenticate(). This file intentionally has no googleCallback export
// to avoid dead-code divergence. See authRoutes.js for the full OAuth flow.

// ─── FACEBOOK COMPLETE (no-email flow) ───────────────────────────────────────
// Called from the complete-profile page when Facebook didn't supply an email.
// Creates the account using the email the user typed, then returns tokens so
// subsequent API calls (profile update, send-otp, etc.) are authenticated.
const facebookComplete = async (req, res) => {
  try {
    const { facebookId, email, name, role, phoneNumber } = req.body;

    if (!facebookId || !email || !name) {
      return res.status(400).json({ message: 'facebookId, email, and name are required' });
    }

    const normalizedEmail = email.toLowerCase().trim();

    // Reject if email already exists — same dedup rule as everywhere else
    const existing = await User.findOne({ email: normalizedEmail });
    if (existing) {
      // If somehow this Facebook ID already linked, just log them in
      if (existing.authProviders?.includes('facebook')) {
        const accessToken = generateAccessToken(existing._id);
        const refreshToken = generateRefreshToken(existing._id);
        setRefreshCookie(res, refreshToken);
        setRoleCookie(res, existing.role);
        return res.json({
          _id: existing._id,
          name: existing.name,
          email: existing.email,
          role: existing.role,
          token: accessToken,
          alreadyExists: true,
        });
      }
      // Different account with same email — link Facebook to it
      if (!existing.authProviders) existing.authProviders = ['password'];
      if (!existing.authProviders.includes('facebook')) {
        existing.authProviders.push('facebook');
        await existing.save();
      }
      const accessToken = generateAccessToken(existing._id);
      const refreshToken = generateRefreshToken(existing._id);
      setRefreshCookie(res, refreshToken);
      setRoleCookie(res, existing.role);
      return res.json({
        _id: existing._id,
        name: existing.name,
        email: existing.email,
        role: existing.role,
        token: accessToken,
        alreadyExists: true,
      });
    }

    // Create new user
    const user = await User.create({
      name,
      email: normalizedEmail,
      password: Math.random().toString(36).slice(-16) + 'Aa1!',
      role: role || 'tenant',
      phoneNumber: phoneNumber || '0000000000',
      isVerified: true,
      authProviders: ['facebook'],
    });

    const accessToken = generateAccessToken(user._id);
    const refreshToken = generateRefreshToken(user._id);
    setRefreshCookie(res, refreshToken);
    setRoleCookie(res, user.role);

    res.status(201).json({
      _id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      token: accessToken,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ─── FCM TOKEN ────────────────────────────────────────────────────────────────
const registerFCMToken = async (req, res) => {
  try {
    const { fcmToken } = req.body;
    if (!fcmToken) return res.status(400).json({ message: 'FCM token required' });
    await User.findByIdAndUpdate(req.user._id, { fcmToken });
    res.json({ message: 'Push notification token registered' });
  } catch (error) { res.status(500).json({ message: error.message }); }
};

// ─── OAUTH ABANDON ───────────────────────────────────────────────────────────
// Called when a Google/Facebook user closes or cancels the complete-profile /
// phone-verification flow. Deletes the incomplete account so the next sign-in
// starts fresh rather than hitting a half-created record.
const abandonOAuthAccount = async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    if (!user) return res.status(404).json({ message: 'User not found' });

    // Safety: only wipe accounts that are still unverified at the phone level
    // and were created via OAuth. Never delete a fully set-up account.
    const isOAuth = Array.isArray(user.authProviders) &&
      user.authProviders.some(p => p !== 'password');
    const incomplete = !user.isPhoneVerified;

    if (!isOAuth || !incomplete) {
      return res.status(400).json({ message: 'Account is already complete — cannot abandon.' });
    }

    await User.findByIdAndDelete(user._id);
    const isProd = process.env.NODE_ENV === 'production';
    res.clearCookie('userRole');
    res.clearCookie('refreshToken', {
      httpOnly: true,
      secure: isProd,
      sameSite: isProd ? 'none' : 'lax',
      path: '/',
    });
    res.json({ message: 'Incomplete account removed.' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  setRefreshCookie, // ← [FIX] exported so authRoutes.js OAuth callback uses same config
  setRoleCookie,
  registerUser, loginUser, superLogin, refreshToken, logoutUser,
  verifyEmail, resendVerification,
  forgotPassword, resetPassword,
  sendPhoneOTP, verifyPhoneOTP,
  setup2FA, verify2FA, disable2FA, send2FADisableOTP, validate2FALogin,
  registerFCMToken, facebookComplete,
  abandonOAuthAccount,
};